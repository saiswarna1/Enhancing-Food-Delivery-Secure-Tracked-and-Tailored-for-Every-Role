package com.zosh.service;

import com.zosh.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
