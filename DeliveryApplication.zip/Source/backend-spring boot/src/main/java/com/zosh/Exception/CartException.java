package com.zosh.Exception;

public class CartException extends Exception {

	public CartException(String message) {
		super(message);
	}

}
